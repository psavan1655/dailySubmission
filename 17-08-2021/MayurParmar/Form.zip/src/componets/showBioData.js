import React, { useState } from "react";

const ShowBioData = (props) => {
  const [visible, setVisible] = useState("none");
  props.value.display === "1" ? setVisible("none") : setVisible("visible");

  return <div style={{ display: `${visible}` }}>dsds</div>;
};

export default ShowBioData;

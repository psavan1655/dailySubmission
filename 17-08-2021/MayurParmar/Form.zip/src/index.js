import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import App from "./App";
import { BrowserRouter, Route } from "react-router-dom";
import ShowBioData from "./componets/showBioData";

ReactDOM.render(
  <React.StrictMode>
    <BrowserRouter>
      <Route exact path="/" component={App}></Route>
      <Route exact path="/show" component={ShowBioData}></Route>
    </BrowserRouter>
  </React.StrictMode>,
  document.getElementById("root")
);
